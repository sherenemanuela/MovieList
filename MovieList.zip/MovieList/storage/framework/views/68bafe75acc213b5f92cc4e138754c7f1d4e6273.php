<?php $__env->startSection('title', 'Edit Movie | MovieList'); ?>

<?php $__env->startSection('navbar'); ?>
    <?php echo $__env->make('adminNavbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</nav>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="add-movie">
<form action="" method="post" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <div class="add">
        <h2>Edit Movie</h2>
        <label for="title" class="form-label">Title</label>
        <input type="text" name="title" class="form-control" id="title" value="<?php echo e($movie->title); ?>">
        <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <?php echo e($message); ?>

        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="add">
        <label for="description" class="form-label">Description</label>
        <textarea name="description" class="form-control" id="description" rows="3"><?php echo e($movie->description); ?></textarea>
        <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <?php echo e($message); ?>

        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="add">
        <label for="genre" class="form-label">Genre</label>
        <br>
        <select name="genres[]" id="genre" class="selectpicker" multiple>
            <?php $__currentLoopData = $genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option id="<?php echo e($g->id); ?>" value="<?php echo e($g->genre); ?>"><?php echo e($g->genre); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
    </div>
    <div id="actor-section" class="add">
        <div class="row">
            <div class="col">
                <label for="actors" class="form-label">Actors</label>
                <select name="actor_1" id="actor" class="form-select">
                    <option selected disabled value="">--Open this select menu--</option>
                    <?php $__currentLoopData = $actors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($a->name); ?>"><?php echo e($a->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col dropdown-column">
                <label for="character-name" class="form-label">Character Name</label>
                <input type="text" name="character_1" class="form-control" id="character-name">
            </div>
        </div>
        <div class="row">
            <div class="col">
                <label for="actors" class="form-label">Actors</label>
                <select name="actor_2" id="actor" class="form-select">
                    <option selected disabled value="">--Open this select menu--</option>
                    <?php $__currentLoopData = $actors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($a->name); ?>"><?php echo e($a->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col dropdown-column">
                <label for="character-name" class="form-label">Character Name</label>
                <input type="text" name="character_2" class="form-control" id="character-name">
            </div>
        </div>
    </div>
    <div class="add d-flex justify-content-end">
        <div id="add-more-actor" class="btn btn-primary btn-add">Add More</div>
    </div>
    <div class="add">
        <label for="director" class="form-label">Director</label>
        <input type="text" name="director" class="form-control" id="director" value="<?php echo e($movie->director); ?>">
        <?php $__errorArgs = ['director'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <?php echo e($message); ?>

        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="add">
        <label for="release" class="form-label">Release Date</label>
        <input type="date" name="release_date" class="form-control" id="release_date" value="<?php echo e($movie->release_date); ?>">
        <?php $__errorArgs = ['release_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <?php echo e($message); ?>

        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="add">
        <label for="image" class="form-label">Image Url</label>
        <input type="file" name="thumbnail" class="form-control" id="thumbnail">
        <?php $__errorArgs = ['thumbnail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <?php echo e($message); ?>

        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="add">
        <label for="background" class="form-label">Background Url</label>
        <input type="file" name="background" class="form-control" id="background">
        <?php $__errorArgs = ['background'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <?php echo e($message); ?>

        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="add">
        <input type="submit" class="form-control" id="btn-create" value="Edit">
    </div>
</form>
</div>

<script>
$(document).ready(function(){
    var ctr = 3;
    $('#add-more-actor').on('click', function(){
        var id = 'actor-' + ctr;
        $('#actor-section').append(`
            <div class="row">
                <div class="col">
                    <label for="actors" class="form-label">Actors</label>
                    <select name="actor_` + ctr + `" id="actor" class="form-select">
                        <option selected disabled value="">--Open this select menu--</option>
                        <?php $__currentLoopData = $actors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($a->name); ?>"><?php echo e($a->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="col dropdown-column">
                    <label for="character-name" class="form-label">Character Name</label>
                    <input type="text" name="character_` + ctr + `" class="form-control" id="character-name">
                </div>
            </div>`);
            ctr++;
    })
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\valen\OneDrive\Documents\Movie List(5)\Movie List\Movie List\MovieList\resources\views/editMovie.blade.php ENDPATH**/ ?>