

<?php $__env->startSection('title', 'Admin'); ?>

<?php $__env->startSection('navbar'); ?>
<nav class="navbar navbar-expand-lg">
    <div class="container-fluid">
      <a class="navbar-brand text-white ms-5" href="<?php echo e(url('admin')); ?>">
          <span class="logo1">Movie</span><span class="logo2">List</span>
      </a>
      <button class="navbar-toggler bg-white" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse justify-content-end" id="navbarSupportedContent">
        <ul class="navbar-nav">
          <li class="nav-item">
            <a class="nav-link active text-white" aria-current="page" href="<?php echo e(url('/admin')); ?>">Home</a>
          </li>
          <li class="nav-item">
            <a class="nav-link text-white" href="#">Movies</a>
          </li>
          <li class="nav-item">
            <a class="nav-link text-white" href="#">Actors</a>
          </li>
          <li class="nav-item">
            <a class="nav-link text-white" href="#">My Watchlist</a>
          </li>
          <li class="nav-item">
            <a class="nav-link text-white" href=""><i class="fa-solid fa-circle-user fa-xl"></i></a>
          </li>
        </ul>
      </div>
    </div>
</nav>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="container profile-container">
    <h2 class="logo1 text-center">Update Profile</h2>

    <div id="profile-container">
        <div class="profile-left">
            <h2 class="logo1"><span class="logo2">My</span>Profile</h2>
            <div class="profile-image" data-bs-toggle="modal" data-bs-target="#profile-modal">
                <?php if($user->image == ''): ?>
                    <i id="edit-profile-picture" class="fa-solid fa-user"></i>
                <?php else: ?>
                    <img id="edit-profile-picture" src="/images/1.jpg">
                <?php endif; ?>
            </div>
            <p><?php echo e($user->username); ?></p>
            <p><?php echo e($user->email); ?></p>
        </div>
        
        <form enctype="multipart/form-data" action="/update-profile" method="POST" class="profile-right">
            <?php echo csrf_field(); ?>
            <div class="form">
                <div class="input-group">
                <div class="label">Username</div>
                    <input type="text" name="username" class="form-input" id="username" value="<?php echo e($user->username); ?>">
                </div>
            </div>
            <div class="form">
                <div class="input-group">
                <div class="label">Email</div>
                    <input type="email" name="email" class="form-input" id="email" value="<?php echo e($user->email); ?>">
                </div>
            </div>
            <div class="form">
                <div class="input-group">
                <div class="label">DOB</div>
                    <input type="date" name="dob" class="form-input" id="dob" value="<?php echo e($user->dob); ?>">
                </div>
            </div>
            <div class="form">
                <div class="input-group">
                <div class="label">Phone</div>
                    <input type="text" name="phone" class="form-input" id="phone" value="<?php echo e($user->phone); ?>">
                </div>
            </div>
            <div class="form">
                <input type="submit" class="btn-login" value="Save Changes">
            </div>
        </form>
    </div>

    <div class="modal fade" id="profile-modal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Update Image</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
            <div class="modal-body">
                <input type="text" name="image-url" class="form-input" id="image-url" placeholder="Image URL">
            </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button id="save-profile-picture" type="button" class="btn btn-primary save-watchlist">Save changes</button>
                </div>
            </div>
        </div>
      </div>
</div>
<script src="/js/profile.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\emanu\Downloads\Movie List\Movie List\Movie List\MovieList\resources\views/profile.blade.php ENDPATH**/ ?>