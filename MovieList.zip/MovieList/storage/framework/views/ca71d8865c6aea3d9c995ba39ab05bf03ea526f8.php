<?php $__env->startSection('title', 'Admin'); ?>

<?php $__env->startSection('navbar'); ?>
<nav class="navbar navbar-expand-lg">
    <div class="container-fluid">
      <a class="navbar-brand text-white ms-5" href="<?php echo e(url('admin')); ?>">
          <span class="logo1">Movie</span><span class="logo2">List</span>
      </a>
      <button class="navbar-toggler bg-white" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse justify-content-end" id="navbarSupportedContent">
        <ul class="navbar-nav">
          <li class="nav-item">
            <a class="nav-link active text-white" aria-current="page" href="<?php echo e(url('')); ?>">Home</a>
          </li>
          <li class="nav-item">
            <a class="nav-link text-white" href="#">Movies</a>
          </li>
          <li class="nav-item">
            <a class="nav-link text-white" href="#">Actors</a>
          </li>
          <li class="nav-item">
            <a class="nav-link text-white" href=""><i class="fa-solid fa-circle-user fa-xl"></i></a>
          </li>
        </ul>
      </div>
    </div>
</nav>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <h1>ADMINNNNNN</h1>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\valen\OneDrive\Documents\Movie List(1)\Movie List\Movie List\MovieList\resources\views/admin.blade.php ENDPATH**/ ?>