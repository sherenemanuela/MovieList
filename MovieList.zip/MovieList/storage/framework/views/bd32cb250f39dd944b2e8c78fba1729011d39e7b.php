<nav class="navbar navbar-expand-lg">
    <div class="container-fluid">
      <a class="navbar-brand text-white ms-5" href="<?php echo e(url('')); ?>">
          <span class="logo1">Movie</span><span class="logo2">List</span>
      </a>
      <button class="navbar-toggler bg-white" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse justify-content-end" id="navbarSupportedContent">
        <ul class="navbar-nav">
          <li class="nav-item">
            <a class="nav-link active text-white" aria-current="page" href="<?php echo e(url('')); ?>">Home</a>
          </li>
          <li class="nav-item">
            <a class="nav-link text-white" href="#">Movies</a>
          </li>
          <li class="nav-item">
            <a class="nav-link text-white" href="#">Actors</a>
          </li>
          <li class="nav-item">
            <a href="<?php echo e(url('register')); ?>"><button class="btn btn-primary mx-3">Register</button></a>
        </li>
        <li class="nav-item">
            <a href="<?php echo e(url('login')); ?>"><button class="btn btn-outline-primary">Login</button></a>
        </li>
        </ul>
      </div>
    </div>
</nav><?php /**PATH C:\Users\emanu\Downloads\Movie List\Movie List\Movie List\MovieList\resources\views/guestNavbar.blade.php ENDPATH**/ ?>