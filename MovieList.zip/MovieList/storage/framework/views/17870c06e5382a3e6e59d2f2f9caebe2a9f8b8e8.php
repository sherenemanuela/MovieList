<?php $__env->startSection('title', 'Actors | MovieList'); ?>

<?php $__env->startSection('navbar'); ?>
    <?php if($user == 'member'): ?>
        <?php echo $__env->make('userNavbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php elseif($user == 'admin'): ?>
        <?php echo $__env->make('adminNavbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php else: ?>
        <?php echo $__env->make('guestNavbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="actors-container">
        <div class="actors-header">
            <div class="header-title">
                <h1>Actors</h1>
            </div>
            <div class="admin-access">
                <input id="search" type="search" class="form-control" placeholder="Actor Address">
                <?php if($user == 'admin'): ?>
                    <a href="<?php echo e(url('add-actor')); ?>"><button class="btn btn-danger">Add Actor</button></a>
                <?php endif; ?>
            </div>
        </div>
        <div class="row row-cols-5 actors" id="show">
            <?php $__currentLoopData = $actors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $actor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e(url('actors-'.$actor->id.'-'.$actor->name)); ?>" >
                <div class="col actor-card" style="margin-bottom: 30px">
                    <div class="card" style="width: 15rem; height: 25rem; background-color: #191919;margin:0;">
                        <img src="<?php echo e(url('storage/actors/'.$actor->image)); ?>" class="card-img-top">
                        <div class="card-body">
                            <p><strong><?php echo e($actor->name); ?></strong></p>
                            <p class="card-text"><?php echo e($actor->title); ?></p>
                        </div>
                    </div>
                </div>
            </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <script>
    $(document).ready(function(){
        $('#search').on('keyup',function(){
            var query= $(this).val();
            $.ajax({
                url:"actor-search",
                type:"GET",
                data:{'search':query},
                success:function(data){
                    $('#show').html(data);
                }
            });
        });
    });
    </script>

<script>
   function loadMoreData(page)
   {
      $.ajax({
         url:'?page=' + page,
         type:'get',
         beforeSend: function()
         {
            $(".actors").show();
         }
      })
      .done(function(data){
         $(".actors").append();
      })
      // Call back function
      .fail(function(jqXHR,ajaxOptions,thrownError){
         alert("Server not responding.....");
      });

   }
   //function for Scroll Event
   var page =1;
   $(window).scroll(function(){
      if($(window).scrollTop() + $(window).height() >= $(document).height()){
         page++;
         loadMoreData(page);
      }
   });
   </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\emanu\Documents\Kuliah\SEMESTER 5\WEB PROGRAMMING\Movie List\Movie List\MovieList\resources\views/actors.blade.php ENDPATH**/ ?>