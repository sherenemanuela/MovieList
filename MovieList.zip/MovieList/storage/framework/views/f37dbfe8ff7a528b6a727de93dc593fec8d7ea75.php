<?php $__env->startSection('title', 'Add Actor'); ?>

<?php $__env->startSection('navbar'); ?>
<nav class="navbar navbar-expand-lg">
    <div class="container-fluid">
      <a class="navbar-brand text-white ms-5" href="#">
          <span class="logo1">Movie</span><span class="logo2">List</span>
      </a>
      <button class="navbar-toggler bg-white" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse justify-content-end" id="navbarSupportedContent">
        <ul class="navbar-nav">
          <li class="nav-item">
            <a class="nav-link active text-white" aria-current="page" href="<?php echo e(url('')); ?>">Home</a>
          </li>
          <li class="nav-item">
            <a class="nav-link text-white" href="#">Movies</a>
          </li>
          <li class="nav-item">
            <a class="nav-link text-white" href="#">Actors</a>
          </li>
          <li class="nav-item">
            <a class="nav-link text-white" href=""><i class="fa-solid fa-circle-user fa-xl"></i></a>
          </li>
        </ul>
      </div>
    </div>
</nav>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="add-actor">
<form action="/add-actor" method="post">
    <?php echo csrf_field(); ?>
    <div class="add">
        <h2>Add Actor</h2>
        <label for="name" class="form-label">Name</label>
        <input type="text" name="title" class="form-control" id="title">
    </div>
    <div class="add">
        <label for="gender" class="form-label">Gender</label>
        <select name="gender" id="gender" class="form-select">
            <option selected disabled value="">--Open this select menu--</option>
            <option value="male">Male</option>
            <option value="female">Female</option>
        </select>
    </div>
    <div class="add">
        <label for="biography" class="form-label">Biography</label>
        <textarea class="form-control" id="biography" rows="3"></textarea>
    </div>
    <div class="add">
        <label for="dob" class="form-label">Date of Birth</label>
        <input type="date" name="dob" class="form-control" id="dob">
    </div>
    <div class="add">
        <label for="pob" class="form-label">Place of Birth</label>
        <input type="text" name="pob" class="form-control" id="pob">
    </div>
    <div class="add">
        <label for="image" class="form-label">Image Url</label>
        <input type="file" name="image-url" class="form-control" id="image-url">
    </div>
    <div class="add">
        <label for="popularity" class="form-label">Popularity</label>
        <input type="number" name="popularity" class="form-control" id="popularity">
    </div>
    <div class="add">
        <input type="submit" class="form-control" id="btn-create" value="Create">
    </div>
</form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\valen\OneDrive\Documents\Movie List(1)\Movie List\Movie List\MovieList\resources\views/addActor.blade.php ENDPATH**/ ?>