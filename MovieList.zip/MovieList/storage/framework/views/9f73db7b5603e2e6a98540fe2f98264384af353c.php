<?php $__env->startSection('title', 'Add Movie | MovieList'); ?>

<?php $__env->startSection('navbar'); ?>
    <?php echo $__env->make('adminNavbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</nav>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="add-movie">
<form action="/add-movie" method="post">
    <?php echo csrf_field(); ?>
    <div class="add">
        <h2>Add Movie</h2>
        <label for="title" class="form-label">Title</label>
        <input type="text" name="title" class="form-control" id="title">
    </div>
    <div class="add">
        <label for="description" class="form-label">Description</label>
        <textarea class="form-control" id="description" rows="3"></textarea>
    </div>
    <div class="add">
        <label for="genre" class="form-label">Genre</label>
        <br>
        <select name="genres" id="genre" class="selectpicker" multiple>
            <?php $__currentLoopData = $genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($g->genre); ?>"><?php echo e($g->genre); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
    </div>
    <div id="actor-section" class="add">
        <div class="row">
            <div class="col">
                <label for="actors" class="form-label">Actors</label>
                <select name="actor" id="actor" class="form-select">
                    <option selected disabled value="">--Open this select menu--</option>
                    <?php $__currentLoopData = $actors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($a->name); ?>"><?php echo e($a->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col dropdown-column">
                <label for="character-name" class="form-label">Character Name</label>
                <input type="text" name="character-name" class="form-control" id="character-name">
            </div>
        </div>
        <div class="row">
            <div class="col">
                <label for="actors" class="form-label">Actors</label>
                <select name="actor" id="actor" class="form-select">
                    <option selected disabled value="">--Open this select menu--</option>
                    <?php $__currentLoopData = $actors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($a->name); ?>"><?php echo e($a->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col dropdown-column">
                <label for="character-name" class="form-label">Character Name</label>
                <input type="text" name="character-name" class="form-control" id="character-name">
            </div>
        </div>
    </div>
    <div class="add d-flex justify-content-end">
        <div id="add-more-actor" class="btn btn-primary btn-add">Add More</div>
    </div>
    <div class="add">
        <label for="director" class="form-label">Director</label>
        <input type="text" name="director" class="form-control" id="director">
    </div>
    <div class="add">
        <label for="release" class="form-label">Release Date</label>
        <input type="date" name="releade-date" class="form-control" id="release-date">
    </div>
    <div class="add">
        <label for="image" class="form-label">Image Url</label>
        <input type="file" name="image-url" class="form-control" id="image-url">
    </div>
    <div class="add">
        <label for="background" class="form-label">Background Url</label>
        <input type="file" name="background-url" class="form-control" id="background-url">
    </div>
    <div class="add">
        <input type="submit" class="form-control" id="btn-create" value="Create">
    </div>
</form>
</div>

<script src="/js/addMovie.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\valen\OneDrive\Documents\Movie List(4)\Movie List\Movie List\Movie List\MovieList\resources\views/addMovie.blade.php ENDPATH**/ ?>