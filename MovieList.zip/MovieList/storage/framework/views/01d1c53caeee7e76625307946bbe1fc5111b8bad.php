<?php $__env->startSection('title', 'MovieList'); ?>

<?php $__env->startSection('navbar'); ?>
  <?php echo $__env->make('guestNavbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div id="main-carousel" class="carousel slide" data-bs-ride="carousel">
  <div class="carousel-indicators">
    <button type="button" data-bs-target="#main-carousel" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
    <button type="button" data-bs-target="#main-carousel" data-bs-slide-to="1" aria-label="Slide 2"></button>
    <button type="button" data-bs-target="#main-carousel" data-bs-slide-to="2" aria-label="Slide 3"></button>
  </div>
  <div class="carousel-inner">
    <div class="carousel-item active" data-bs-interval="5000">
      <img src="<?php echo e(url('storage/backgrounds/'.$rMovies[0]->background)); ?>" class="d-block w-100">
      <div id="main-carousel-caption" class="carousel-caption d-none d-md-block">
        <p><?php echo e($rMovies[0]->genre . ' | ' . $rMovies[0]->date); ?></p>
        <h1><?php echo e($rMovies[0]->title); ?></h1>
        <p><?php echo e($rMovies[0]->description); ?>.</p>
      </div>
    </div>
    <?php for($i = 1; $i <= 2; $i++): ?>
      <div class="carousel-item" data-bs-interval="5000">
        <img src="<?php echo e(url('storage/backgrounds/'.$rMovies[$i]->background)); ?>" class="d-block w-100">
        <div id="main-carousel-caption" class="carousel-caption d-none d-md-block">
          <p><?php echo e($rMovies[$i]->genre . ' | ' . $rMovies[$i]->date); ?></p>
          <h1><?php echo e($rMovies[$i]->title); ?></h1>
          <p><?php echo e($rMovies[$i]->description); ?></p>
        </div>
      </div>
    <?php endfor; ?>
  </div>
</div>

<div class="movie-list-header">
    <div class="header-title">
        <i class="fa-solid fa-fire-flame-curved"></i>
        Popular
    </div>
</div>
<div class="movie-list">
  <?php $__currentLoopData = $pMovies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <a href="/movie-detail-<?php echo e($p->id); ?>">
    <div class="movie-item">
        <img src="<?php echo e(url('storage/thumbnails/'.$p->thumbnail)); ?>">
        <div class="movie-info">
            <p class="movie-title"><?php echo e($p->title); ?></p>
            <p class="movie-year"><?php echo e($p->date); ?></p>
        </div>
    </div>
  </a>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<div class="movie-list-header">
    <div class="header-title">
        <i class="fa-regular fa-film"></i>
        Show
    </div>
    <input id="search" type="search" class="form-control" placeholder="Search movie..">
</div>

<div id="movie-section">
  <div id="genre-navbar" class="filter">
    <div class="genre-container">
      <div class="genre-wrapper">
        <?php $__currentLoopData = $genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <button id="<?php echo e($g->genre); ?>" type="button" class="btn btn-light genre-choice"><?php echo e($g->genre); ?></button>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div>
    <i id="genre-left-btn" class="fa-regular fa-circle-chevron-left genre-btn"></i>
    <i id="genre-right-btn" class="fa-regular fa-circle-chevron-right genre-btn"></i>
  </div>

  <div id="sort-navbar" class="filter"> Sort By
      <button id="sort-latest" type="button" class="btn btn-light">Latest</button>
      <button id="sort-asc" type="button" class="btn btn-light">A-Z</button>
      <button id="sort-desc" type="button" class="btn btn-light">Z-A</button>
  </div>

  <div id="show" class="movie-list">
    <?php $__currentLoopData = $movies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <a href="/movie-detail-<?php echo e($m->id); ?>">
        <div class="movie-item">
            <img src="<?php echo e(url('/storage/thumbnails/'.$m->thumbnail)); ?>">
            <div class="movie-info">
                <p class="movie-title"><?php echo e($m->title); ?></p>
                <p class="movie-year"><?php echo e($m->date); ?></p>
            </div>
        </div>
      </a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
</div>

<script src="/js/home.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\emanu\Downloads\2440008916_BV01_COMP6681001_5f13d6a0-8781-11ed-bef3-c3493f7f93db\2440009143_BV01_COMP6681001_f6102d40-8742-11ed-9999-fd39df5b8691\Final Project Movie List\Movie List\Movie List\Movie List\MovieList\resources\views/guest.blade.php ENDPATH**/ ?>