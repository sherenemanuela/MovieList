<?php $__env->startSection('title', $actor->name.' | MovieList'); ?>

<?php $__env->startSection('navbar'); ?>
    <?php if($user == 'member'): ?>
        <?php echo $__env->make('userNavbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php elseif($user == 'admin'): ?>
        <?php echo $__env->make('adminNavbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php else: ?>
        <?php echo $__env->make('guestNavbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="actor-container">
        <div class="left-container">
            <div class="actor-image">
                <img src="<?php echo e(url('storage/actors/'.$actor->image)); ?>" alt="">
                <a href="<?php echo e(url('edit-actor-'.$actor->id.'-'.$actor->name)); ?>"><i class="fa-solid fa-pen-to-square"></i></a>
                <a href="<?php echo e(url('delete-actor-'.$actor->id.'-'.$actor->name)); ?>"><i class="fa-solid fa-trash-can"></i></a>
            </div>
            <h4>Personal Info</h4>
            <div class="info">
                <p><strong>Popularity</strong></p>
                <p><?php echo e($actor->popularity); ?></p>
            </div>
            <div class="info">
                <p><strong>Gender</strong></p>
                <p><?php echo e($actor->gender); ?></p>
            </div>
            <div class="info">
                <p><strong>Birthday</strong></p>
                <p class="actor-info"><?php echo e($actor->dob); ?></p>
            </div>
            <div class="info">
                <p><strong>Place of Birth</strong></p>
                <p><?php echo e($actor->birth_place); ?></p>
            </div>
        </div>
        <div class="right-container">
            <h1><?php echo e($actor->name); ?></h1>
            <h5>Biography</h5>
            <p><?php echo e($actor->biography); ?></p>
            <h5>Known For</h5>
            <?php $__currentLoopData = $movies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="movie-card" style="width: 10rem; height: 16rem; background-color: #191919;margin:0;">
                <img src="<?php echo e(url('storage/backgrounds/'.$movie->background)); ?>" class="card-img-top">
                <div class="movie-card-body">
                    <a href="<?php echo e(url('movie-detail-'.$movie->movie_id)); ?>"><p><?php echo e($movie->title); ?></p></a>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\emanu\Downloads\Movie List\Movie List\MovieList\resources\views/actorDetail.blade.php ENDPATH**/ ?>