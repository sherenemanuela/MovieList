<nav class="navbar navbar-expand-lg">
    <div class="container-fluid">
      <a class="navbar-brand text-white ms-5" href="<?php echo e(url('admin')); ?>">
          <span class="logo1">Movie</span><span class="logo2">List</span>
      </a>
      <button class="navbar-toggler bg-white" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse justify-content-end" id="navbarSupportedContent">
        <ul class="navbar-nav">
          <li class="nav-item">
            <a class="nav-link active text-white" aria-current="page" href="<?php echo e(url('/admin')); ?>">Home</a>
          </li>
          <li class="nav-item">
            <a class="nav-link text-white" href="<?php echo e(url('admin')); ?>">Movies</a>
          </li>
          <li class="nav-item">
            <a class="nav-link text-white" href="<?php echo e(url('actors')); ?>">Actors</a>
          </li>
          <li class="nav-item-profile" id="nav-dropdown">
            <div href=""><i class="fa-solid fa-circle-user fa-xl"></i></div>
            <div id="nav-dropdown-content" class="dropdown-content">
                <div class="d-flex flex-column">
                    <a href="/profile">Profile</a>
                    <hr id="hr">
                    <a href="/logout" id="logout">Logout</a>
                </div>
            </div>
          </li>
        </ul>
      </div>
    </div>
</nav>

<script src="/js/navbar.js"></script>
<?php /**PATH C:\Users\valen\OneDrive\Documents\Movie List(4)\Movie List\Movie List\Movie List\MovieList\resources\views/adminNavbar.blade.php ENDPATH**/ ?>