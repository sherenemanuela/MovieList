<?php $__env->startSection('title', 'Register | MovieList'); ?>

<?php $__env->startSection('navbar'); ?>
  <?php echo $__env->make('guestNavbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="login register">
        <h3>Hello, Welcome to <span class="logo1">Movie</span><span class="logo2">List</span></h3>
        <form action="/register" method="post">
            <?php echo csrf_field(); ?>
            <div class="form">
                <div class="input-group">
                  <div class="label">Username</div>
                  <input type="text" name="username" class="form-input" id="username" value="<?php echo e(old('username')); ?>" placeholder="Enter your username">
                  <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <?php echo e($message); ?>

                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <div class="form">
                <div class="input-group">
                  <div class="label">Email</div>
                  <input type="email" name="email" class="form-input" id="email" value="<?php echo e(old('email')); ?>" placeholder="Enter your email">
                  <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <?php echo e($message); ?>

                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <div class="form">
                <div class="input-group">
                  <div class="label">Password</div>
                  <input type="password" name="password" class="form-input" id="password" placeholder="Enter your password">
                  <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <?php echo e($message); ?>

                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <div class="form">
                <div class="input-group">
                  <div class="label">Confirm Password</div>
                  <input type="password" name="confirm-password" class="form-input" id="confirm-password" placeholder="Enter your confirm password">
                  <?php $__errorArgs = ['confirm-password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <?php echo e($message); ?>

                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <div class="form">
                <input type="submit" class="btn-login btn-register" value="Register ->">
            </div>
        </form>
        <p>Already have an account? <span class="now"><a href="<?php echo e(url('login')); ?>">Login now!</a></span></p>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\valen\OneDrive\Documents\Movie List(6)\Movie List\Movie List\MovieList\resources\views/register.blade.php ENDPATH**/ ?>