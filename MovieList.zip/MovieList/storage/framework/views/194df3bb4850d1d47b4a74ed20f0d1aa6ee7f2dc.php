

<?php $__env->startSection('title', 'Admin'); ?>

<?php $__env->startSection('navbar'); ?>
  <?php echo $__env->make('userNavbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="container watchlist-title">
        <i class="fa-solid fa-bookmark"></i>
        <span class="logo2">My</span><span class="logo1">Watchlist</span>
    </div>
    <div class="movie-search">
        <input id="watchlist-search" type="search" class="form-control" placeholder="Search movie..">
        <i class="fa-solid fa-magnifying-glass"></i>
    </div>
    <div class="movie-filter">
        <i class="fa-sharp fa-solid fa-filter"></i>
        <select id="movie-filter" class="form-select form-select-sm" aria-label=".form-select-lg example">
            <option selected value="All">All</option>
            <option value="Planned">Planned</option>
            <option value="Watching">Watching</option>
            <option value="Finished">Finished</option>
        </select>
    </div>
    <table class="table table-dark" id="watchlist-table">
        <thead>
          <tr>
            <th>Poster</th>
            <th>Title</th>
            <th>Status</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody id="watchlist-body">
            <?php $__currentLoopData = $movies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>
                        <img src="<?php echo e($m->thumbnail); ?>">
                    </td>
                    <td><?php echo e($m->title); ?></td>
                    <td class="watchlist-status"><?php echo e($m->status); ?></td>
                    <td>
                        <i id="<?php echo e($m->movie_id); ?>" class="fa-solid fa-ellipsis watchlist-action" data-bs-toggle="modal" data-bs-target="#status-modal"></i>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
      <div id="paginator-detail">
        Showing <?php echo e($movies->firstItem()); ?> to <?php echo e($movies->lastItem()); ?> of <?php echo e($movies->total()); ?> results
        <?php echo e($movies->links('pagination::bootstrap-4')); ?>

      </div>
      <div class="modal fade" id="status-modal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Change Status</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
            <div class="modal-body">
                <select id="status-selection" class="form-select form-select-sm" aria-label=".form-select-lg example">
                    <option value="Planned" selected>Planned</option>
                    <option value="Watching">Watching</option>
                    <option value="Finished">Finished</option>
                    <option value="Remove">Remove</option>
                </select>
            </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button id="save-status" type="button" class="btn btn-primary save-watchlist">Save changes</button>
                </div>
            </div>
        </div>
      </div>
</div>
<script src="/js/watchlist.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\valen\OneDrive\Documents\Movie List(4)\Movie List\Movie List\Movie List\MovieList\resources\views/watchlist.blade.php ENDPATH**/ ?>