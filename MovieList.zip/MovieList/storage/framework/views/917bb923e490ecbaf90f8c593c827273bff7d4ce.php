<?php $__env->startSection('title', 'Actors'); ?>

<?php $__env->startSection('navbar'); ?>
<nav class="navbar navbar-expand-lg">
    <div class="container-fluid">
      <a class="navbar-brand text-white ms-5" href="<?php echo e(url('admin')); ?>">
          <span class="logo1">Movie</span><span class="logo2">List</span>
      </a>
      <button class="navbar-toggler bg-white" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse justify-content-end" id="navbarSupportedContent">
        <ul class="navbar-nav">
          <li class="nav-item">
            <a class="nav-link active text-white" aria-current="page" href="<?php echo e(url('')); ?>">Home</a>
          </li>
          <li class="nav-item">
            <a class="nav-link text-white" href="#">Movies</a>
          </li>
          <li class="nav-item">
            <a class="nav-link text-white" href="<?php echo e(url('actors-admin')); ?>">Actors</a>
          </li>
          <li class="nav-item">
            <a class="nav-link text-white" href=""><i class="fa-solid fa-circle-user fa-xl"></i></a>
          </li>
        </ul>
      </div>
    </div>
</nav>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="actors-container">
        <div class="actors-header">
            <div class="header-title">
                <h1>Actors</h1>
            </div>
            <div class="admin-access">
                <input id="search" type="search" class="form-control" placeholder="Actor Address">
                <a href="<?php echo e(url('add-actor')); ?>"><button class="btn btn-danger">Add Actor</button></a>
            </div>
        </div>
        <div class="row row-cols-5" id="show">
            <?php $__currentLoopData = $actors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $actor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col actor-card">
                    <div class="card" style="width: 15rem; height: 25rem; background-color: #191919;margin:0;">
                        <img src="<?php echo e(asset('storage/actors/'.$actor->image)); ?>" class="card-img-top">
                        <div class="card-body">
                            <a href="<?php echo e(url('actors/'.$actor->id.'/'.$actor->name)); ?>" ><p><strong><?php echo e($actor->name); ?></strong></p></a>
                            <p class="card-text"><?php echo e($actor->title); ?></p>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <script>
    $(document).ready(function(){
        $('#search').on('keyup',function(){
            var query= $(this).val();
            $.ajax({
                url:"actor-search",
                type:"GET",
                data:{'search':query},
                success:function(data){
                    $('#show').html(data);
                }
            });
        });
    });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\valen\OneDrive\Documents\Movie List(2)\Movie List\Movie List\Movie List\MovieList\resources\views/actorsAdmin.blade.php ENDPATH**/ ?>