<?php $__env->startSection('title', 'Register'); ?>

<?php $__env->startSection('navbar'); ?>
<nav class="navbar navbar-expand-lg">
    <div class="container-fluid">
      <a class="navbar-brand text-white ms-5" href="<?php echo e(url('')); ?>">
          <span class="logo1">Movie</span><span class="logo2">List</span>
      </a>
      <button class="navbar-toggler bg-white" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse justify-content-end" id="navbarSupportedContent">
        <ul class="navbar-nav">
          <li class="nav-item">
            <a class="nav-link active text-white" aria-current="page" href="<?php echo e(url('')); ?>">Home</a>
          </li>
          <li class="nav-item">
            <a class="nav-link text-white" href="#">Movies</a>
          </li>
          <li class="nav-item">
            <a class="nav-link text-white" href="#">Actors</a>
          </li>
          <li class="nav-item">
            <a href="<?php echo e(url('register')); ?>"><button class="btn btn-primary mx-3">Register</button></a>
        </li>
        <li class="nav-item">
            <a href="<?php echo e(url('login')); ?>"><button class="btn btn-outline-primary">Login</button></a>
        </li>
        </ul>
      </div>
    </div>
</nav>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="login register">
        <h3>Hello, Welcome to <span class="logo1">Movie</span><span class="logo2">List</span></h3>
        <form action="/register" method="post">
            <?php echo csrf_field(); ?>
            <div class="form">
                <div class="input-group">
                  <div class="label">Username</div>
                  <input type="text" name="username" class="form-input" id="username" value="<?php echo e(old('username')); ?>" placeholder="Enter your username">
                  <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <?php echo e($message); ?>

                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <div class="form">
                <div class="input-group">
                  <div class="label">Email</div>
                  <input type="email" name="email" class="form-input" id="email" value="<?php echo e(old('email')); ?>" placeholder="Enter your email">
                  <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <?php echo e($message); ?>

                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <div class="form">
                <div class="input-group">
                  <div class="label">Password</div>
                  <input type="password" name="password" class="form-input" id="password" placeholder="Enter your password">
                  <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <?php echo e($message); ?>

                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <div class="form">
                <div class="input-group">
                  <div class="label">Confirm Password</div>
                  <input type="password" name="confirm-password" class="form-input" id="confirm-password" placeholder="Enter your confirm password">
                  <?php $__errorArgs = ['confirm-password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <?php echo e($message); ?>

                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <div class="form">
                <input type="submit" class="btn-login btn-register" value="Register ->">
            </div>
        </form>
        <p>Already have an account? <span class="now"><a href="<?php echo e(url('login')); ?>">Login now!</a></span></p>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\valen\OneDrive\Documents\Movie List(4)\Movie List\Movie List\Movie List\MovieList\resources\views/register.blade.php ENDPATH**/ ?>