

<?php $__env->startSection('title', 'Admin'); ?>

<?php $__env->startSection('navbar'); ?>
    <?php echo $__env->make('userNavbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div id="movie-banner">
        <div id="background-container">
            <img id="background" src="<?php echo e($movie->first()->background); ?>">
        </div>
        <div class="inner-movie">
            <img src="<?php echo e($movie->first()->thumbnail); ?>">
            <div class="movie-detail">
                <h2><?php echo e($movie->first()->title); ?></h2>
                <div class="movie-genres d-flex">
                    <?php $__currentLoopData = $genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <p><?php echo e($g->genre); ?></p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <p>Release Year</p>
                <p><?php echo e($movie->first()->date); ?></p>
                <h5>Storyline</h5>
                <p><?php echo e($movie->first()->description); ?></p>
                <h5><?php echo e($movie->first()->director); ?></h5>
                <p>Director</p>
            </div>
            <?php if($user == 'admin'): ?>
                <div class="admin-edit-movie">
                    <a href=""><i class="fa-regular fa-pen-to-square"></i></a>
                    <i id="<?php echo e($movie->first()->id); ?>" class="fa-regular fa-trash-can remove-movie"></i>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <div class="section-container">
        <h4><span>|</span>Cast</h4>
        <div class="inner-section d-flex">
            <?php $__currentLoopData = $casts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="cast-card">
                    <div class="cast-pic">
                        <img src="/images/actors/<?php echo e($c->image); ?>">
                    </div>
                    <div class="cast-card-detail">
                        <h5><?php echo e($c->name); ?></h5>
                        <p><?php echo e($c->character); ?></p>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

    <div class="section-container">
        <h4><span>|</span>More</h4>
        <div class="inner-section">
            <div id="show" class="movie-list">
                <?php $__currentLoopData = $moreMovies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="/movie-detail-<?php echo e($m->id); ?>">
                        <div class="movie-item">
                            <img src="<?php echo e($m->thumbnail); ?>">
                            <div class="movie-info">
                                <p class="movie-title"><?php echo e($m->title); ?></p>
                                <p class="movie-year"><?php echo e($m->date); ?></p>
                                <?php if($user == 'member'): ?>
                                    <?php if($watchlist->first() == null): ?>
                                        <i id="<?php echo e($m->id); ?>" class="fa-solid fa-plus add-watchlist"></i>
                                    <?php else: ?>
                                    <?php ($exist = false); ?>
                                        <?php $__currentLoopData = $watchlist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $w): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($w->movie_id == $m->id): ?>
                                                <i id="<?php echo e($m->id); ?>" class="fa-solid fa-check remove-watchlist"></i>
                                                <?php ($exist = true); ?>
                                                <?php break; ?>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($exist == false): ?>
                                        <i id="<?php echo e($m->id); ?>" class="fa-solid fa-plus add-watchlist"></i>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </div>
                        </div>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</div>
<script src="/js/watchlist.js"></script>
<script src="/js/movieDetail.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\emanu\Downloads\Movie List\Movie List\Movie List\MovieList\resources\views/movieDetail.blade.php ENDPATH**/ ?>