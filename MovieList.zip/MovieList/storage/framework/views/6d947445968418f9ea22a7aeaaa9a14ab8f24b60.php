<?php $__env->startSection('title', 'Actors'); ?>

<?php $__env->startSection('navbar'); ?>
    <?php echo $__env->make('guestNavbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="actors-container">
        <div class="actors-header">
            <div class="header-title">
                <h1>Actors</h1>
            </div>
        </div>
        <div class="row row-cols-5" id="show">
            <?php $__currentLoopData = $actors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $actor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col actor-card">
                    <div class="card" style="width: 15rem; height: 25rem; background-color: #191919;margin:0;">
                        <img src="<?php echo e(asset('storage/actors/'.$actor->image)); ?>" class="card-img-top">
                        <div class="card-body">
                            <a href="<?php echo e(url('actors/'.$actor->id.'/'.$actor->name)); ?>" ><p><strong><?php echo e($actor->name); ?></strong></p></a>
                            <p class="card-text"><?php echo e($actor->title); ?></p>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <script>
    $(document).ready(function(){
        $('#search').on('keyup',function(){
            var query= $(this).val();
            $.ajax({
                url:"actor-search",
                type:"GET",
                data:{'search':query},
                success:function(data){
                    $('#show').html(data);
                }
            });
        });
    });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\valen\OneDrive\Documents\Movie List(4)\Movie List\Movie List\Movie List\MovieList\resources\views/actorsGuest.blade.php ENDPATH**/ ?>