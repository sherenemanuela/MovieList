<?php $__env->startSection('title', 'Edit Movie'); ?>

<?php $__env->startSection('navbar'); ?>
<nav class="navbar navbar-expand-lg">
    <div class="container-fluid">
      <a class="navbar-brand text-white ms-5" href="#">
          <span class="logo1">Movie</span><span class="logo2">List</span>
      </a>
      <button class="navbar-toggler bg-white" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse justify-content-end" id="navbarSupportedContent">
        <ul class="navbar-nav">
          <li class="nav-item">
            <a class="nav-link active text-white" aria-current="page" href="<?php echo e(url('')); ?>">Home</a>
          </li>
          <li class="nav-item">
            <a class="nav-link text-white" href="#">Movies</a>
          </li>
          <li class="nav-item">
            <a class="nav-link text-white" href="#">Actors</a>
          </li>
          <li class="nav-item">
            <a class="nav-link text-white" href=""><i class="fa-solid fa-circle-user fa-xl"></i></a>
          </li>
        </ul>
      </div>
    </div>
</nav>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="add-movie">
<form action="/edit-movie" method="post">
    <?php echo csrf_field(); ?>
    <div class="add">
        <h2>Edit Movie</h2>
        <label for="title" class="form-label">Title</label>
        <input type="text" name="title" class="form-control" id="title">
    </div>
    <div class="add">
        <label for="description" class="form-label">Description</label>
        <textarea class="form-control" id="description" rows="3"></textarea>
    </div>
    <div class="add">
        <label for="genre" class="form-label">Genre</label>
          <select name="genres[]" id="genre" class="form-select" multiple-size="1">
            <option selected disabled value="">Select an option</option>
            <option value="crime">Crime</option>
            <option value="drama">Drama</option>
            <option value="family">Family</option>
            <option value="fantasy">Fantasy</option>
            <option value="history">History</option>
            <option value="horror">Horror</option>
          </select>
    </div>
    <div class="add">
        <div class="row">
            <div class="col">
                <label for="actors" class="form-label">Actors</label>
                <select name="actor" id="actor" class="form-select">
                    <option selected disabled value="">--Open this select menu--</option>
                    <option value="actor1">Actor1</option>
                </select>
            </div>
            <div class="col">
                <label for="character-name" class="form-label">Character Name</label>
                <input type="text" name="character-name" class="form-control" id="character-name">
            </div>
        </div>
        <div class="row">
            <div class="col">
                <label for="actors" class="form-label">Actors</label>
                <select name="actor" id="actor" class="form-select">
                    <option selected disabled value="">--Open this select menu--</option>
                    <option value="actor1">Actor1</option>
                </select>
            </div>
            <div class="col">
                <label for="character-name" class="form-label">Character Name</label>
                <input type="text" name="character-name" class="form-control" id="character-name">
            </div>
        </div>
    </div>
    <div class="add">
        <a href=""><button class="btn btn-primary btn-add">Add More</button></a>
    </div>
    <div class="add">
        <label for="director" class="form-label">Director</label>
        <input type="text" name="director" class="form-control" id="director">
    </div>
    <div class="add">
        <label for="release" class="form-label">Release Date</label>
        <input type="date" name="releade-date" class="form-control" id="release-date">
    </div>
    <div class="add">
        <label for="image" class="form-label">Image Url</label>
        <input type="file" name="image-url" class="form-control" id="image-url">
    </div>
    <div class="add">
        <label for="background" class="form-label">Background Url</label>
        <input type="file" name="background-url" class="form-control" id="background-url">
    </div>
    <div class="add">
        <input type="submit" class="form-control" id="btn-create" value="Edit">
    </div>
</form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\valen\OneDrive\Documents\Movie List(1)\Movie List\Movie List\MovieList\resources\views/editMovie.blade.php ENDPATH**/ ?>