<?php $__env->startSection('title', 'Login | MovieList'); ?>

<?php $__env->startSection('navbar'); ?>
  <?php echo $__env->make('guestNavbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="login">
        <h3>Hello, Welcome back to <span class="logo1">Movie</span><span class="logo2">List</span></h3>
        <?php if(Session::has('alert')): ?>
            <h5><?php echo e(Session::get('alert')); ?></h5>
        <?php endif; ?>
        <form action="/login" method="post">
            <?php echo csrf_field(); ?>
            <div class="form">
                <div class="input-group">
                  <div class="label">Email</div>
                  <input type="email" name="email" class="form-input" id="email" placeholder="Enter your email" value=<?php echo e(Cookie::get('cookie') !== null ? Cookie::get('cookie') : ""); ?>>
                  <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <?php echo e($message); ?>

                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <div class="form">
                <div class="input-group">
                  <div class="label">Password</div>
                  <input type="password" name="password" class="form-input" id="password" placeholder="Enter your password">
                  <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <?php echo e($message); ?>

                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <input type="checkbox" name="remember" id="remember" checked=<?php echo e(Cookie::get('cookie') !==null); ?>> Remember me
            <div class="form">
                <input type="submit" class="btn-login" value="Login ->">
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <?php echo e($message); ?>

                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </form>
        <p>Don't have an account? <span class="now"><a href="<?php echo e(url('register')); ?>">Register now!</a></span></p>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\emanu\Downloads\Final Project Movie List\MovieList\resources\views/login.blade.php ENDPATH**/ ?>