@extends('template')

@section('title', 'Profile | MovieList')

@section('navbar')
    @if($user->role == 'member')
        @include('userNavbar')
    @elseif($user->role == 'admin')
        @include('adminNavbar')
    @else
        @include('guestNavbar')
    @endif
@endsection

@section('content')

<div class="container profile-container">
    <h2 class="logo1 text-center">Update Profile</h2>

    <div id="profile-container">
        <div class="profile-left">
            <h2 class="logo1"><span class="logo2">My </span>Profile</h2>
            <div class="profile-image" data-bs-toggle="modal" data-bs-target="#profile-modal">
                @if($user->image == '')
                    <i id="edit-profile-picture" class="fa-solid fa-user"></i>
                @else
                    <img id="edit-profile-picture" src="{{$user->image}}">
                @endif
            </div>
            <p>{{ $user->username }}</p>
            <p>{{ $user->email }}</p>
        </div>

        <form enctype="multipart/form-data" action="/update-profile" method="POST" class="profile-right">
            @csrf
            <div class="form">
                <div class="input-group">
                <div class="label">Username</div>
                    <input type="text" name="username" class="form-input" id="username" value="{{ $user->username }}">
                    @error('username')
                        {{$message}}
                    @enderror
                </div>
            </div>
            <div class="form">
                <div class="input-group">
                <div class="label">Email</div>
                    <input type="email" name="email" class="form-input" id="email" value="{{ $user->email }}">
                    @error('email')
                        {{$message}}
                    @enderror
                </div>
            </div>
            <div class="form">
                <div class="input-group">
                <div class="label">DOB</div>
                    <input type="date" name="dob" class="form-input" id="dob" value="{{ $user->dob }}">
                    @error('dob')
                        {{$message}}
                    @enderror
                </div>
            </div>
            <div class="form">
                <div class="input-group">
                <div class="label">Phone</div>
                    <input type="text" name="phone" class="form-input" id="phone" value="{{ $user->phone }}">
                    @error('phone')
                        {{$message}}
                    @enderror
                </div>
            </div>
            <div class="form">
                <input type="submit" class="btn-login" value="Save Changes">
            </div>
        </form>
    </div>

    <div class="modal fade" id="profile-modal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Update Image</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
            <div class="modal-body">
                <input type="text" name="image-url" class="form-input" id="image-url" placeholder="Image URL">
                @error('image-url')
                    {{$message}}
                @enderror
            </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button id="save-profile-picture" type="button" class="btn btn-primary save-watchlist">Save changes</button>
                </div>
            </div>
        </div>
      </div>
</div>
<script src="/js/profile.js"></script>
@endsection
