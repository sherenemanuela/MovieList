@extends('template')

@section('title', 'Register | MovieList')

@section('navbar')
  @include('guestNavbar')
@endsection

@section('content')
    <div class="login register">
        <h3>Hello, Welcome to <span class="logo1">Movie</span><span class="logo2">List</span></h3>
        <form action="/register" method="post">
            @csrf
            <div class="form">
                <div class="input-group">
                  <div class="label">Username</div>
                  <input type="text" name="username" class="form-input" id="username" value="{{old('username')}}" placeholder="Enter your username">
                  @error('username')
                    {{$message}}
                  @enderror
                </div>
            </div>
            <div class="form">
                <div class="input-group">
                  <div class="label">Email</div>
                  <input type="email" name="email" class="form-input" id="email" value="{{old('email')}}" placeholder="Enter your email">
                  @error('email')
                    {{$message}}
                  @enderror
                </div>
            </div>
            <div class="form">
                <div class="input-group">
                  <div class="label">Password</div>
                  <input type="password" name="password" class="form-input" id="password" placeholder="Enter your password">
                  @error('password')
                    {{$message}}
                  @enderror
                </div>
            </div>
            <div class="form">
                <div class="input-group">
                  <div class="label">Confirm Password</div>
                  <input type="password" name="confirm-password" class="form-input" id="confirm-password" placeholder="Enter your confirm password">
                  @error('confirm-password')
                    {{$message}}
                  @enderror
                </div>
            </div>
            <div class="form">
                <input type="submit" class="btn-login btn-register" value="Register ->">
            </div>
        </form>
        <p>Already have an account? <span class="now"><a href="{{url('login')}}">Login now!</a></span></p>
    </div>
@endsection
