@extends('template')

@section('title', 'Edit Actor | '.$actor->name)

@section('navbar')
    @include('adminNavbar')
@endsection
@section('content')
<div class="add-actor">
<form action="" method="post" enctype="multipart/form-data">
    @csrf
    <div class="add">
        <h2>Edit Actor</h2>
        <label for="name" class="form-label">Name</label>
        <input type="text" name="name" class="form-control" id="name" value="{{$actor->name}}">
        @error('name')
            {{$message}}
        @enderror
    </div>
    <div class="add">
        <label for="gender" class="form-label">Gender</label>
        <select name="gender" id="gender" class="form-select">
            <option selected disabled value="">--Open this select menu--</option>
            <option value="male">Male</option>
            <option value="female">Female</option>
        </select>
        @error('gender')
            {{$message}}
        @enderror
    </div>
    <div class="add">
        <label for="biography" class="form-label">Biography</label>
        <textarea name="biography" class="form-control" id="biography" rows="3">{{$actor->biography}}</textarea>
        @error('biography')
            {{$message}}
        @enderror
    </div>
    <div class="add">
        <label for="dob" class="form-label">Date of Birth</label>
        <input type="date" name="dob" class="form-control" id="dob" value="{{$actor->dob}}">
        @error('dob')
            {{$message}}
        @enderror
    </div>
    <div class="add">
        <label for="pob" class="form-label">Place of Birth</label>
        <input type="text" name="birth_place" class="form-control" id="birth_place" value="{{$actor->birth_place}}">
        @error('birth_place')
            {{$message}}
        @enderror
    </div>
    <div class="add">
        <label for="image" class="form-label">Image Url</label>
        <input type="file" name="image" class="form-control" id="image">
        @error('image')
            {{$message}}
        @enderror
    </div>
    <div class="add">
        <label for="popularity" class="form-label">Popularity</label>
        <input type="text" name="popularity" class="form-control" id="popularity" value="{{$actor->popularity}}">
        @error('popularity')
            {{$message}}
        @enderror
    </div>
    <div class="add">
        <input type="submit" class="form-control" id="btn-create" value="Edit">
    </div>
</form>
</div>
@endsection
