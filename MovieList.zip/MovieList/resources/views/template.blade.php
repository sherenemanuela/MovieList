<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>@yield('title')</title>
    <link rel="stylesheet" href="css/app.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.13.1/css/bootstrap-select.css" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.13.1/js/bootstrap-select.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>
    <script src="https://kit.fontawesome.com/aee2802e7b.js" crossorigin="anonymous"></script>
</head>
<body>
    @yield('navbar')
    @yield('content')
</body>
<footer>
    <h1>
        <span class="logo1">Movie</span><span class="logo2">List</span>
    </h1>
    <p>
        <span class="logo1">Movie</span><span class="logo2">List</span> is a Website that contains list of movie</p>
    <div class="footer-icon">
        <a href=""><i class="fa-brands fa-square-twitter fa-2xl"></i></a>
        <a href=""><i class="fa-brands fa-square-instagram fa-2xl"></i></a>
        <a href=""><i class="fa-brands fa-facebook fa-2xl"></i></a>
        <a href=""><i class="fa-brands fa-youtube fa-2xl"></i></a>
    </div>
    <div class="footer-menu">
        <a href="">Privacy Policy</a>
        <p>|</p>
        <a href="">Terms of Service</a>
        <p>|</p>
        <a href="">Contact Us</a>
        <p>|</p>
        <a href="">About Us</a>
    </div>
    <p>Copyright &copy 2021
        <span class="logo1">Movie</span><span class="logo2">List</span> All Rights Reserved</p>
</footer>
</html>
