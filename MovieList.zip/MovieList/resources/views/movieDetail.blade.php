@extends('template')

@section('title', $movie->first()->title.' | MovieList')

@section('navbar')
    @if($user == 'member')
        @include('userNavbar')
    @elseif($user == 'admin')
        @include('adminNavbar')
    @else
        @include('guestNavbar')
    @endif
@endsection

@section('content')
    <div id="movie-banner">
        <div id="background-container">
            <img id="background" src="{{url('storage/backgrounds/'.$movie->first()->background)}}">
        </div>
        <div class="inner-movie">
            <img src="{{url('storage/thumbnails/'.$movie->first()->thumbnail)}}">
            <div class="movie-detail">
                <h2>{{ $movie->first()->title }}</h2>
                <div class="movie-genres d-flex">
                    @foreach($genres as $g)
                        <p>{{ $g->genre }}</p>
                    @endforeach
                </div>
                <p>Release Year</p>
                <p>{{ $movie->first()->date }}</p>
                <h5>Storyline</h5>
                <p>{{ $movie->first()->description }}</p>
                <h5>{{ $movie->first()->director }}</h5>
                <p>Director</p>
            </div>
            @if($user == 'admin')
                <div class="admin-edit-movie">
                    <a href="{{url('edit-movie-'.$movie->first()->id)}}"><i class="fa-regular fa-pen-to-square"></i></a>
                    <a href="{{url('delete-movie-'.$movie->first()->id)}}"><i class="fa-regular fa-trash-can remove-movie"></i></a>
                </div>
            @endif
        </div>
    </div>

    <div class="section-container">
        <h4><span>|</span>Cast</h4>
        <div class="inner-section d-flex">
            @foreach($casts as $c)
            <a href="{{url('actors-'.$c->id.'-'.$c->name)}}" style="text-decoration: none; color: white;">
                <div class="cast-card">
                    <div class="cast-pic">
                        <img src="{{url('storage/actors/'.$c->image)}}">
                    </div>
                    <div class="cast-card-detail">
                        <h5>{{ $c->name }}</h5>
                        <p>{{ $c->character }}</p>
                    </div>
                </div>
            </a>
            @endforeach
        </div>
    </div>

    <div class="section-container">
        <h4><span>|</span>More</h4>
        <div class="inner-section">
            <div id="show" class="movie-list">
                @foreach ($moreMovies as $m)
                    <a href="/movie-detail-{{ $m->id }}">
                        <div class="movie-item">
                            <img src="{{url('storage/thumbnails/'.$m->thumbnail)}}">
                            <div class="movie-info">
                                <p class="movie-title">{{ $m->title }}</p>
                                <p class="movie-year">{{ $m->date }}</p>
                                @if($user == 'member')
                                    @if($watchlist->first() == null)
                                        <i id="{{ $m->id }}" class="fa-solid fa-plus add-watchlist"></i>
                                    @else
                                    @php($exist = false)
                                        @foreach($watchlist as $w)
                                            @if($w->movie_id == $m->id)
                                                <i id="{{ $m->id }}" class="fa-solid fa-check remove-watchlist"></i>
                                                @php($exist = true)
                                                @break
                                            @endif
                                        @endforeach
                                        @if($exist == false)
                                        <i id="{{ $m->id }}" class="fa-solid fa-plus add-watchlist"></i>
                                        @endif
                                    @endif
                                @endif
                            </div>
                        </div>
                    </a>
                @endforeach
            </div>
        </div>
    </div>
</div>
<script src="/js/watchlist.js"></script>
<script src="/js/movieDetail.js"></script>
@endsection
