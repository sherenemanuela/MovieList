@extends('template')

@section('title', 'Login | MovieList')

@section('navbar')
  @include('guestNavbar')
@endsection

@section('content')
    <div class="login">
        <h3>Hello, Welcome back to <span class="logo1">Movie</span><span class="logo2">List</span></h3>
        @if (Session::has('alert'))
            <h5>{{Session::get('alert')}}</h5>
        @endif
        <form action="/login" method="post">
            @csrf
            <div class="form">
                <div class="input-group">
                  <div class="label">Email</div>
                  <input type="email" name="email" class="form-input" id="email" placeholder="Enter your email" value={{Cookie::get('cookie') !== null ? Cookie::get('cookie') : ""}}>
                  @error('email')
                    {{$message}}
                  @enderror
                </div>
            </div>
            <div class="form">
                <div class="input-group">
                  <div class="label">Password</div>
                  <input type="password" name="password" class="form-input" id="password" placeholder="Enter your password">
                  @error('password')
                      {{$message}}
                  @enderror
                </div>
            </div>
            <input type="checkbox" name="remember" id="remember" checked={{Cookie::get('cookie') !==null}}> Remember me
            <div class="form">
                <input type="submit" class="btn-login" value="Login ->">
                @error('email')
                    {{$message}}
                @enderror
            </div>
        </form>
        <p>Don't have an account? <span class="now"><a href="{{url('register')}}">Register now!</a></span></p>
    </div>
@endsection
