@extends('template')

@section('title', $actor->name.' | MovieList')

@section('navbar')
    @if($user == 'member')
        @include('userNavbar')
    @elseif($user == 'admin')
        @include('adminNavbar')
    @else
        @include('guestNavbar')
    @endif
@endsection

@section('content')
    <div class="actor-container">
        <div class="left-container">
            <div class="actor-image position-relative">
                <img src="{{url('storage/actors/'.$actor->image)}}" style="border-radius: 10px; border: white solid 2px;">
                @if ($user == 'admin')
                <div style="position: absolute; display:flex; flex-direction:column; top: 10px; right: 10px; z-index: 999;">
                    <a href="{{url('edit-actor-'.$actor->id.'-'.$actor->name)}}"><i class="fa-solid fa-pen-to-square"></i></a>
                    <a href="{{url('delete-actor-'.$actor->id.'-'.$actor->name)}}"><i class="fa-solid fa-trash-can"></i></a>
                </div>
                @endif
            </div>
            <h4>Personal Info</h4>
            <div class="info">
                <p><strong>Popularity</strong></p>
                <p>{{$actor->popularity}}</p>
            </div>
            <div class="info">
                <p><strong>Gender</strong></p>
                <p>{{$actor->gender}}</p>
            </div>
            <div class="info">
                <p><strong>Birthday</strong></p>
                <p class="actor-info">{{$actor->dob}}</p>
            </div>
            <div class="info">
                <p><strong>Place of Birth</strong></p>
                <p>{{$actor->birth_place}}</p>
            </div>
        </div>
        <div class="right-container">
            <h1 style="margin-bottom: 20px;">{{$actor->name}}</h1>
            <h5>Biography</h5>
            <p>{{$actor->biography}}</p>
            <h5>Known For</h5>
            @foreach ($movies as $movie)
            <div class="movie-card" style="width: 10rem; height: 16rem; background-color: #191919;margin:20px 0; border-radius: 10px;">
                <img src="{{url('storage/thumbnails/'.$movie->thumbnail)}}" class="card-img-top">
                <div class="movie-card-body">
                    <a href="{{url('movie-detail-'.$movie->movie_id)}}"><p>{{$movie->title}}</p></a>
                </div>
            </div>
            @endforeach
        </div>
    </div>
@endsection
