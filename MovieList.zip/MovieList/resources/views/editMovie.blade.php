@extends('template')

@section('title', 'Edit Movie | MovieList')

@section('navbar')
    @include('adminNavbar')
</nav>
@endsection
@section('content')
<div class="add-movie">
<form action="/edit-movie-{{$movie->id}}" method="post" enctype="multipart/form-data">
    @csrf
    <div class="add">
        <h2>Edit Movie</h2>
        <label for="title" class="form-label">Title</label>
        <input type="text" name="title" class="form-control" id="title" value="{{$movie->title}}">
        @error('title')
            {{$message}}
        @enderror
    </div>
    <div class="add">
        <label for="description" class="form-label">Description</label>
        <textarea name="description" class="form-control" id="description" rows="3">{{$movie->description}}</textarea>
        @error('description')
            {{$message}}
        @enderror
    </div>
    <div class="add">
        <label for="genre" class="form-label">Genre</label>
        <br>
        <select name="genres[]" id="genre" class="selectpicker" multiple>
            @foreach ($genres as $g)
                <option id="{{ $g->id }}" value="{{ $g->genre }}">{{ $g->genre }}</option>
            @endforeach
          </select>
    </div>
    <div id="actor-section" class="add">
        @foreach($movieActors as $ma)
            @php($char = '')
            <div class="row">
                <div class="col">
                    <label for="actors" class="form-label">Actors</label>
                    <select name="actor_1" id="actor" class="form-select">
                        <option selected disabled value="">--Open this select menu--</option>
                        @foreach ($actors as $a)
                            @if($a->name == $ma->name)
                                <option value="{{ $a->name }}" selected>{{ $a->name }}</option>
                                @php($char = $ma->character)
                            @else
                                <option value="{{ $a->name }}">{{ $a->name }}</option>
                            @endif
                        @endforeach
                    </select>
                </div>
                <div class="col dropdown-column">
                    <label for="character-name" class="form-label">Character Name</label>
                    <input type="text" name="character_1" class="form-control" id="character-name" value="{{$char}}">
                </div>
            </div>
        @endforeach
    </div>
    <div class="add d-flex justify-content-end">
        <div id="add-more-actor" class="btn btn-primary btn-add">Add More</div>
    </div>
    <div class="add">
        <label for="director" class="form-label">Director</label>
        <input type="text" name="director" class="form-control" id="director" value="{{$movie->director}}">
        @error('director')
            {{$message}}
        @enderror
    </div>
    <div class="add">
        <label for="release" class="form-label">Release Date</label>
        <input type="date" name="release_date" class="form-control" id="release_date" value="{{$movie->release_date}}">
        @error('release_date')
            {{$message}}
        @enderror
    </div>
    <div class="add">
        <label for="image" class="form-label">Image Url</label>
        <input type="file" name="thumbnail" class="form-control" id="thumbnail">
        @error('thumbnail')
            {{$message}}
        @enderror
    </div>
    <div class="add">
        <label for="background" class="form-label">Background Url</label>
        <input type="file" name="background" class="form-control" id="background">
        @error('background')
            {{$message}}
        @enderror
    </div>
    <div class="add">
        <input type="submit" class="form-control" id="btn-create" value="Edit">
    </div>
</form>
</div>

<script>
$(document).ready(function(){
    var ctr = 3;
    $('#add-more-actor').on('click', function(){
        var id = 'actor-' + ctr;
        $('#actor-section').append(`
            <div class="row">
                <div class="col">
                    <label for="actors" class="form-label">Actors</label>
                    <select name="actor_` + ctr + `" id="actor" class="form-select">
                        <option selected disabled value="">--Open this select menu--</option>
                        @foreach ($actors as $a)
                            <option value="{{ $a->name }}">{{ $a->name }}</option>
                        @endforeach
                    </select>
                </div>
                <div class="col dropdown-column">
                    <label for="character-name" class="form-label">Character Name</label>
                    <input type="text" name="character_` + ctr + `" class="form-control" id="character-name">
                </div>
            </div>`);
            ctr++;
    })
});
</script>
@endsection
