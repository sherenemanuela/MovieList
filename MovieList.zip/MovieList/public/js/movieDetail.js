$(document).ready(function(){
    $('.remove-movie').on('click',function(){
        var query= $(this).get(0).id;
        $.ajax({
            url:"remove-movie",
            type:"GET",
            data:{'movie_id': query},
            success:function(data){
                alert("Successfully Deleted");
                window.location.href = "/admin";
            }
        });
    });
});