$(document).ready(function(){
    let wrapper = document.getElementsByClassName('genre-wrapper')[0];
    var pos = 0;

    $('#genre-left-btn').on('click',function(){
      wrapper.style.transform = "translateX(" + (pos + 200) + "px)";
      wrapper.style.transition="all 0.5s"
      pos += 200;
    });

    $('#genre-right-btn').on('click',function(){
      wrapper.style.transform = "translateX(" + (pos - 200) + "px)";
      wrapper.style.transition="all 0.5s"
      pos -= 200;
    });

    $('#search').on('keyup',function(){
        var query= $(this).val();
        $.ajax({
          url:"home-search",
          type:"GET",
          data:{'search':query},
          success:function(data){
            $('#show').html(data);
          }
        });
    });

    $('.genre-choice').on('click', function(){
      var query = $(this).get(0).id;
      $.ajax({
          url:"genre",
          type:"GET",
          data:{'genre':query},
          success:function(data){
            $('#show').html(data);
          }
      });
    });

    $('#sort-latest').on('click', function(){
      var query = $(this).id;
      $.ajax({
          url:"sort-latest",
          type:"GET",
          data:{'sort':query},
          success:function(data){
            $('#show').html(data);
          }
      });
    });

    $('#sort-desc').on('click', function(){
      var query = $(this).id;
      $.ajax({
          url:"sort-desc",
          type:"GET",
          data:{'sort':query},
          success:function(data){
            $('#show').html(data);
          }
      });
    });
    
    $('#sort-asc').on('click', function(){
      var query = $(this).id;
      $.ajax({
          url:"sort-asc",
          type:"GET",
          data:{'sort':query},
          success:function(data){
            $('#show').html(data);
          }
      });
    });
});