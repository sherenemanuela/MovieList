$(document).ready(function(){
    $('.add-watchlist').on('click',function(){
        var query= $(this).get(0).id;
        $.ajax({
          url:"add-watchlist",
          type:"GET",
          data:{'movie_id':query},
          success:function(){
            location.reload();
          }
        });
    });

    $('.remove-watchlist').on('click',function(){
        var query= $(this).get(0).id;
        $.ajax({
          url:"remove-watchlist",
          type:"GET",
          data:{'movie_id':query},
          success:function(){
            location.reload();
          }
        });
    });

    $('#watchlist-search').on('keyup',function(){
      var query= $(this).val();
      $.ajax({
        url:"watchlist-search",
        type:"GET",
        data:{'search':query},
        success:function(data){
          $('#watchlist-body').html(data);
        }
      });
    });

    $('.watchlist-action').on('click',function(){
      var query= $(this).get(0).id;

      $('#save-status').on('click', function(){
        var status = $('#status-selection').val();

        if(status == 'Remove'){
          $.ajax({
            url:"remove-watchlist",
            type:"GET",
            data:{'movie_id': query},
            success:function(){
              location.reload();
            }
          });
        }
        else{
          $.ajax({
            url:"update-watchlist",
            type:"GET",
            data:{'status': status, 'movie_id': query},
            success:function(){
              location.reload();
            }
          });
        }
      });
    });

    $('#movie-filter').on('change',function(){
      var query= $(this).val();
      $.ajax({
        url:"filter-watchlist",
        type:"GET",
        data:{'filter':query},
        success:function(data){
          $('#watchlist-body').html(data);
        }
      });
    });
});