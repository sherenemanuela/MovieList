$(document).ready(function(){
    $('#save-profile-picture').on('click',function(){
        var query= $('#image-url').val();
        $.ajax({
            url:"update-profile-picture",
            type:"GET",
            data:{'url': query},
            success:function(){
              location.reload();
            }
        });
    });
});