$(document).ready(function(){
    $('#nav-dropdown').click(function(){
        $('#nav-dropdown-content').toggle();
    });

    $('#logout').click(function(){
        $.ajax({
            url:"logout",
            type:"GET",
            success:function(){
                window.location.href = "/login";
            }
        });
    });
});