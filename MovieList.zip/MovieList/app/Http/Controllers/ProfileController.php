<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class ProfileController extends Controller
{
    public function profilePage(){
        return view('profile', ['user' => Auth::user()]);
    }

    public function updateProfile(Request $request){

        $this->validate($request, [
            'username' => 'required | min:2 | max:50',
            'email' => 'required | min:8 | email',
            'phone' => 'required | min:5 | max:13',
            'dob' => 'required | date'
        ]);

        DB::table('users')
            ->where('id', Auth::user()->id)
            ->update([
                'username' => $request->username,
                'email' => $request->email,
                'phone' => $request->phone,
                'dob' => $request->dob
        ]);
        return redirect('/profile');
    }

    public function updateProfilePicture(Request $request){
        // $this->validate($request, [
        //     'url' => 'required'
        // ]);

        DB::table('users')
            ->where('id', Auth::user()->id)
            ->update(['image' => $request->url]);
        return redirect('/profile');
    }
}
