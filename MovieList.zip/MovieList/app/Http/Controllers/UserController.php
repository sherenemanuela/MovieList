<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class UserController extends GuestController
{
    public function userPage(){
        return view('user', [
            'pMovies' => $this->getPopularMovies(), 
            'rMovies' => $this->getRandomMovies(), 
            'genres'=> $this->getGenres(),
            'movies'=> $this->getMovies(),
            'watchlist'=>$this->getWatchlist()]);
    }

    public function addWatchlist(Request $request){
        if($request->ajax()){
            if(!$this->duplicateFound($request->movie_id)){
                DB::table('watchlists')
                    ->insert([
                        'movie_id' => $request->movie_id,
                        'user_id' => Auth::user()->id,
                        'status' => 'Planned'
                    ]);
            }
        }
    }

    public function removeWatchlist(Request $request){
        if($request->ajax()){
            DB::table('watchlists')
                ->where([
                    ['movie_id', '=', $request->movie_id],
                    ['user_id', '=', Auth::user()->id]
                ])
                ->delete();
        }
    }

    public function duplicateFound($id){
        $watchlistExist = DB::table('watchlists')
                        ->where([
                            ['movie_id', $id],
                            ['user_id', Auth::user()->id]])
                        ->get();
        if($watchlistExist->first() != null)
            return true;
        return false;
    }

    public function getWatchlist(){
        $username = Auth::user()->username;
        return DB::table('watchlists')
                ->join('users', 'users.id', '=', 'user_id')
                ->where('username', $username)
                ->get();
    }
}
