<?php

namespace App\Http\Controllers;

use Illuminate\Contracts\Cache\Store;
use Illuminate\Http\Request;
use Illuminate\Routing\Route;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Route as FacadesRoute;
use Illuminate\Support\Facades\Storage;

class ActorController extends Controller
{
    public function addActorPage(){
        return view('addActor');
    }

    public function addActor(Request $request){
        $this->validate($request, [
            'name' => 'required | min:3 | unique:actors,name',
            'gender' => 'required',
            'biography' => 'required | min:10',
            'dob' => 'required',
            'birth_place' => 'required',
            'image' => 'required | mimes:jpeg,jpg,png,gif',
            'popularity' => 'required | regex:/[0-9]/'
        ],[
            'name.unique' => 'Actor already exist!',
            'popularity.regex' => 'Popularity must be a number'
        ]);

        Storage::putFileAs('actors', $request->file('image'), $request->file('image')->getClientOriginalName());

        DB::table('actors')->insert([
            'name' => $request->name,
            'gender' => $request->gender,
            'biography' => $request->biography,
            'dob' => $request->dob,
            'birth_place' => $request->birth_place,
            'image' => $request->file('image')->getClientOriginalName(),
            'popularity' => $request->popularity,
        ]);
        return redirect('actors');
    }

    public function editActorPage(Request $request){
        $actor = DB::table('actors')
                ->where('id', 'LIKE', $request->route('id'))
                ->first();
                return view('editActor', ['actor'=>$actor]);
    }

    public function editActor(Request $request){
        $this->validate($request, [
            'name' => 'required | min:3',
            'gender' => 'required',
            'biography' => 'required | min:10',
            'dob' => 'required',
            'birth_place' => 'required',
            'image.*' => 'required | mimes:jpeg,jpg,png,gif',
            'popularity' => 'required | regex:/[0-9]/'
        ],[
            'popularity.regex' => 'Popularity must be a number'
        ]);

        Storage::putFileAs('actors', $request->file('image'), $request->file('image')->getClientOriginalName());

        DB::table('actors')->where('id', $request->route('id'))
            ->update([
            'name' => $request->name,
            'gender' => $request->gender,
            'biography' => $request->biography,
            'dob' => $request->dob,
            'birth_place' => $request->birth_place,
            'image' => $request->file('image')->getClientOriginalName(),
            'popularity' => $request->popularity,
        ]);
        return redirect('actors');

    }

    public function deleteActor(Request $request){
        DB::table('actors')->where('id', $request->route('id'))
            ->delete();

        return redirect('actors');
    }

    public function showActor(){
        $actors = DB::table('actors')
                ->select('actors.id', 'actors.name', 'actors.image', 'movies.title')
                ->leftJoin('movie_actors','actor_id','=','actors.id')
                ->leftJoin('movies','movies.id','=', 'movie_actors.movie_id')
                ->get();
        if(Auth::user() == null){
            return view('actors', ['actors'=>$actors, 'user'=>null]);
        }

        $count = DB::table('actors')
                ->count();

        return view('actors', ['actors'=>$actors, 'user'=>Auth::user()->role, 'count'=>$count]);
    }

    public function search(Request $request){
        if($request->ajax()){
            $data = DB::table('actors')
                    ->select('actors.id','name','image','title')
                    ->leftJoin('movie_actors','actor_id','=','actors.id')
                    ->leftJoin('movies','movies.id','=', 'movie_actors.movie_id')
                    ->where('name', 'LIKE', '%'.$request->search.'%')
                    ->get();
        }
        return $this->outputData($data);
    }

    public function outputData($data){
        $output = '';
        if(count($data) > 0){
            foreach($data as $d){
                $image = url('Storage/actors/'.$d->image);
                $href = url('actors/'.$d->id.'/'.$d->name);
                $output .='
                <div class="col actor-card">
                    <div class="card" style="width: 15rem; height: 25rem; background-color: #191919;margin:0;">
                        <img src="'.$image.'" class="card-img-top">
                        <div class="card-body">
                            <a href="'.$href.'" ><p><strong>'.$d->name.'</strong></p></a>
                            <p class="card-text">'.$d->title.'</p>
                        </div>
                    </div>
                </div>
                ';
            }
        }
        else{
            $output = '<div class="not-found">
            <br><br><br><br><br>
            <h5>No Actor Found</h5>
            </div>';
        }
        return $output;
    }

    public function actorDetail(Request $request){
        $actor = DB::table('actors')
                ->where('id','LIKE',$request->route('id'))
                ->first();
        $movies = DB::table('movies')
                ->join('movie_actors', 'movie_id', 'LIKE', 'movies.id')
                ->where('movie_actors.actor_id', 'LIKE', $request->route('id'))
                ->get();
        if(Auth::user() == null){
            return view('actorDetail',['actor'=>$actor, 'movies'=>$movies, 'user'=>null]);
        }
        return view('actorDetail',['actor'=>$actor, 'movies'=>$movies,'user'=>Auth::user()->role]);
    }
}
