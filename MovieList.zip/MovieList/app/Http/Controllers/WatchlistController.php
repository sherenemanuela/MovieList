<?php

namespace App\Http\Controllers;

use App\Models\Movie;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class WatchlistController extends Controller
{
    public function watchlistPage(){
        return view('watchlist', ['movies' => $this->getWatchlist()]);
    }

    public function getWatchlist(){
        return DB::table('movies')
                ->join('watchlists', 'movie_id', '=', 'movies.id')
                ->where('user_id', Auth::user()->id)
                ->paginate(4);
    }

    public function filterWatchlist(Request $request){

        if($request->ajax()){
            if($request->filter == 'All')
                $data = $this->getWatchlist();
            else{
                $data = DB::table('movies')
                        ->join('watchlists', 'movie_id', '=', 'movies.id')
                        ->where([
                            ['user_id', Auth::user()->id],
                            ['status', $request->filter]
                        ])
                        ->paginate(4);
            }
        }
        return $this->outputData($data);
    }

    public function search(Request $request){
        if($request->ajax()){
            $data = DB::table('movies')
                    ->join('watchlists', 'movie_id', 'movies.id')
                    ->where([
                        ['title', 'like', '%'.$request->search.'%'],
                        ['user_id', Auth::user()->id]
                    ])
                    ->get();
        }
        return $this->outputData($data);
    }

    public function updateStatus(Request $request){
        if($request->ajax()){
            DB::table('watchlists')
                ->where([
                    ['movie_id', '=', $request->movie_id],
                    ['user_id', Auth::user()->id]
                ])
                ->update(['status' => $request->status]);
        }
    }

    public function outputData($data){
        $output = '';
        if(count($data) > 0){
            foreach($data as $m){
                $output .='
                 <tr style="background-color: rgb(21, 21, 21); margin-bottom: 20px; border-bottom: black solid 20px;">
                    <td>
                        <img src="'.url('/storage/thumbnails/'.$m->thumbnail).'">
                    </td>
                    <td>'.$m->title.'</td>
                    <td class="watchlist-status">'.$m->status.'</td>
                    <td>
                        <i id="'.$m->movie_id.'" class="fa-solid fa-ellipsis watchlist-action" data-bs-toggle="modal" data-bs-target="#status-modal"></i>
                    </td>
                </tr>
                ';
            }
        }
        else{
            $output = 'No Movies Found';
        }
        return $output;
    }
}
