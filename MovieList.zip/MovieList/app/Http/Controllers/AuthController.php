<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Cookie;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\MessageBag;

class AuthController extends Controller
{
    public function loginPage(){
        return view('login');
    }

    public function login(Request $request){
        $this->validate($request, [
            'email' => 'required',
            'password' => 'required | min:6',
        ]);

        $credentials = [
            'email' => $request->email,
            'password' => $request->password
        ];

        if($request->remember){
            Cookie::queue('cookie', $request->email, 120);
        }

        if(Auth::attempt($credentials, true)){
            Session::put('session', $credentials);
            if(Auth::user()->role == 'admin'){
                return redirect('admin');
            }else{
                return redirect('browse');
            }
        }

        $errors = new MessageBag(['password' => ['Email and/or password invalid!']]);
        return redirect()->back()->withErrors($errors)->with('email');
    }

    public function adminPage(){
        return view('admin');
    }

    public function registerPage(){
        return view('register');
    }

    public function register(Request $request){
        $this->validate($request, [
            'username' => 'required | min:5 | unique:users,username',
            'email' => 'required | unique:users,email',
            'password' => 'required | min:6 | regex:/[a-z]/ | regex:/[A-Z]/ | regex:/[0-9]/',
            'confirm-password' => 'required | same:password'
        ],[
            'username.unique' => 'Username already exist!',
            'email.unique' => 'Email already exist',
            'password.regex' => 'Password must be at least 6 characters long and contain uppercase, lowercase, and number'

        ]);

        User::create([
            'username' => $request->username,
            'email' => $request->email,
            'password' => bcrypt($request->password)
        ]);
        return redirect('login')->with('alert', 'User Successfuly Created! Please log in with existing account.');
    }

    public function logout(){
        Session::flush();
        Auth::logout();
        return redirect('/login');
    }
}
