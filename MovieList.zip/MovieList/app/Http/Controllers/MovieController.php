<?php

namespace App\Http\Controllers;

use App\Models\Actor;
use App\Models\Genre;
use App\Models\Movie;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;

class MovieController extends Controller
{
    public function addMoviePage(){
        return view('addMovie', [
            'genres' => $this->getGenres(),
            'actors' => $this->getActors()
        ]);
    }

    public function addMovie(Request $request){
        $this->validate($request, [
            'title' => 'required | min:2 | max:50',
            'description' => 'required | min:8',
            'director' => 'required | min:3',
            'release_date' => 'required',
            'thumbnail' => 'required | mimes:jpeg,jpg,png,gif',
            'background' => 'required | mimes:jpeg,jpg,png,gif'
        ]);

        Storage::putFileAs('thumbnails', $request->file('thumbnail'), $request->file('thumbnail')->getClientOriginalName());
        Storage::putFileAs('backgrounds', $request->file('background'), $request->file('background')->getClientOriginalName());

        DB::table('movies')->insert([
            'title' => $request->title,
            'description' => $request->description,
            'director' => $request->director,
            'release_date' => $request->release_date,
            'thumbnail' => $request->file('thumbnail')->getClientOriginalName(),
            'background' => $request->file('background')->getClientOriginalName()
        ]);

        $movie_id = Movie::all()->last()->id;

        foreach($request->genres as $g){
            $genre_row = DB::table('genres')->where('genre', $g)->first();
            $genre_id = $genre_row->id;

            DB::table('movie_genres')
                ->insert([
                    'genre_id' => $genre_id,
                    'movie_id' => $movie_id
                ]);
        }

        $i = 1;
        do{
            $actor = 'actor_'.strval($i);
            $actor_id = DB::table('actors')
                        ->where('name', $request->$actor)
                        ->first()
                        ->id;

            $character = 'character_'.strval($i);
            DB::table('movie_actors')->insert([
                'movie_id' => $movie_id,
                'actor_id' => $actor_id,
                'character' => $request->$character
            ]);
            $i++;
            $next = 'actor_'.strval($i);
        } while ($request->$next != null);

        return redirect('movie-detail-'.$movie_id);
    }

    public function editMoviePage(Request $request){
        $movie = DB::table('movies')
            ->where('id', 'LIKE', $request->route('id'))
            ->first();
        return view('editMovie', [
            'genres' => $this->getGenres(),
            'actors' => $this->getActors(),
            'movie' => $movie,
            'movieActors' => $this->getMovieActors($movie->id)
        ]);
    }

    public function getMovieActors($id){
        return DB::table('movies')
            ->join('movie_actors', 'movie_id','=', 'movies.id')
            ->join('actors', 'actor_id','=', 'actors.id')
            ->where('movie_id', $id)
            ->get();
    }

    public function editMovie(Request $request){
        $this->validate($request, [
            'title' => 'required | min:2 | max:50',
            'description' => 'required | min:8',
            'director' => 'required | min:3',
            'release_date' => 'required',
            'thumbnail' => 'mimes:jpeg,jpg,png,gif',
            'background' => 'mimes:jpeg,jpg,png,gif'
        ]);

        $movie_id = $request->route('id');
        $movie = Movie::find($movie_id);
        $thumbnail = $movie->thumbnail;
        $background = $movie->background;

        if($request->hasFile('thumbnail')){
            Storage::delete('thumbnails'.$movie->thumbnail);
            $thumbnail = $request->file('thumbnail')->getClientOriginalName();
            Storage::putFileAs('thumbnails', $request->file('thumbnail'), $thumbnail);
        }

        if($request->hasFile('background')){
            Storage::delete('backgrounds'.$movie->background);
            $background = $request->file('background')->getClientOriginalName();
            Storage::putFileAs('backgrounds', $request->file('background'), $background);
        }
       
        DB::table('movies')->where('id', $movie_id)
            ->update([
                'title' => $request->title,
                'description' => $request->description,
                'director' => $request->director,
                'release_date' => $request->release_date,
                'thumbnail' => $thumbnail,
                'background' => $background
            ]);


        DB::table('movie_genres')->where('movie_id', $movie_id)->delete();

        foreach($request->genres as $g){
            $genre_row = DB::table('genres')->where('genre', $g)->first();
            $genre_id = $genre_row->id;

            DB::table('movie_genres')
                ->insert([
                    'genre_id' => $genre_id,
                    'movie_id' => $movie_id
                ]);
        }


        DB::table('movie_actors')->where('movie_id', 'LIKE', $movie_id)->delete();

        $i = 1;
        do{
            $actor = 'actor_'.strval($i);
            $actor_id = DB::table('actors')
                        ->where('name', $request->$actor)
                        ->first()
                        ->id;

            $character = 'character_'.strval($i);
            DB::table('movie_actors')->where('movie_id', 'LIKE', $movie_id)
                ->insert([
                'movie_id' => $movie_id,
                'actor_id' => $actor_id,
                'character' => $request->$character
            ]);
            $i++;
            $next = 'actor_'.strval($i);
        } while ($request->$next != null);

        return redirect('movie-detail-'.$movie_id);
    }

    public function deleteMovie(Request $request){
        DB::table('movies')->where('id', $request->route('id'))
            ->delete();
        DB::table('movie_actors')->where('movie_id', 'LIKE', $request->route('id'))
            ->delete();
        DB::table('movie_genres')->where('movie_id', 'LIKE', $request->route('id'))
            ->delete();

        return redirect('actors');
    }

    public function getGenres(){
        return Genre::all();
    }

    public function getActors(){
        return DB::table('actors')
                ->orderBy('name')
                ->get();
    }
}
