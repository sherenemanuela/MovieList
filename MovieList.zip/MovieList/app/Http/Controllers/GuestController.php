<?php

namespace App\Http\Controllers;

use App\Models\Genre;
use App\Models\Movie;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class GuestController extends Controller
{
    public function guestPage(){
        return view('guest', [
            'pMovies' => $this->getPopularMovies(),
            'rMovies' => $this->getRandomMovies(),
            'genres'=> $this->getGenres(),
            'movies'=> $this->getMovies()
        ]);
    }

    public function sortAsc(Request $request){
        if($request->ajax()){
            $data = DB::table('movies')
                    ->select('movies.id', 'title', 'thumbnail', DB::raw('YEAR(release_date) as date'))
                    ->orderBy('title', 'asc')
                    ->get();
        }
        return $this->outputData($data);
    }

    public function sortDesc(Request $request){
        if($request->ajax()){
            $data = DB::table('movies')
                    ->select('movies.id', 'title', 'thumbnail', DB::raw('YEAR(release_date) as date'))
                    ->orderBy('title', 'desc')
                    ->get();
        }
        return $this->outputData($data);
    }

    public function sortLatest(Request $request){
        if($request->ajax()){
            $data = DB::table('movies')
                    ->select('movies.id', 'title', 'thumbnail', DB::raw('YEAR(release_date) as date'))
                    ->orderBy('release_date', 'desc')
                    ->get();
        }
        return $this->outputData($data);
    }

    public function genre(Request $request){
        if($request->ajax()){
            $data = DB::table('movies')
                    ->select('movies.id', 'title', 'thumbnail', DB::raw('YEAR(release_date) as date'))
                    ->join('movie_genres', 'movie_id', '=', 'movies.id')
                    ->join('genres', 'genre_id', '=', 'genres.id')
                    ->where('genre', 'like', '%'.$request->genre.'%')
                    ->get();
        }
        return $this->outputData($data);
    }

    public function search(Request $request){
        if($request->ajax()){
            $data = DB::table('movies')
                    ->select('id', 'title', 'thumbnail', DB::raw('YEAR(release_date) as date'))
                    ->where('title', 'like', '%'.$request->search.'%')
                    ->get();
        }
        return $this->outputData($data);
    }

    public function outputData($data){
        $output = '';
        if(count($data) > 0){
            foreach($data as $d){
                $thumbnail = url('Storage/thumbnails/'.$d->thumbnail);
                $output .='
                    <a href="/movie-detail-'.$d->id.'">
                        <div class="movie-item">
                            <img src="'.$thumbnail.'">
                            <div class="movie-info">
                                <p class="movie-title">'.$d->title.'</p>
                                <p class="movie-year">'.$d->date.'</p>
                            </div>
                        </div>
                    </a>
                ';
            }
        }
        else{
            $output = 'No Movies Found';
        }
        return $output;
    }

    public function getMovies(){
        return DB::table('movies')
                ->select('id', 'title', 'thumbnail', DB::raw('YEAR(release_date) as date'))
                ->get();
    }

    public function getGenres(){
        return DB::table('genres')->get();
    }

    public function getPopularMovies(){
        return DB::table('movies')
                ->select(DB::raw('movies.id as id'), 'title', 'thumbnail', DB::raw('YEAR(release_date) as date'), DB::raw('COUNT(movie_id) as popularity'))
                ->leftJoin('watchlists', 'movie_id', '=', 'movies.id')
                ->groupBy('movies.id', 'movies.title', 'movies.thumbnail', 'date')
                ->orderBy('popularity', 'desc')
                ->limit(15)
                ->get();
    }

    public function getRandomMovies(){
        $movies = DB::table('movies')->inRandomOrder()->limit(3)->get();
        $rMovies = [];

        foreach ($movies as $m) {
            $movie = DB::table('movies')
                    ->select(DB::raw('movies.id as id'), 'title', 'description', 'background', 'genre', DB::raw('YEAR(release_date) as date'))
                    ->join('movie_genres', 'movie_id', '=', 'movies.id')
                    ->join('genres', 'genre_id', '=', 'genres.id')
                    ->where('movie_id', $m->id)
                    ->limit(1)
                    ->get();
            $data = [$movie->first()];
            $rMovies = array_merge($rMovies, $data);
        }
        return $rMovies;
    }
}
