<?php

namespace App\Http\Controllers;

use App\Models\Movie;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Redirect;

class MovieDetailController extends Controller
{
    public function movieDetailPage($id){
        if(Auth::user() == null){
            return view('movieDetail', [
                'moreMovies' => $this->getMoreMovies(),
                'movie' => $this->getMovieDetail($id),
                'casts' => $this->getCasts($id),
                'genres' => $this->getGenres($id),
                'watchlist' => null,
                'user' => null
            ]);
        }
        return view('movieDetail', [
            'moreMovies' => $this->getMoreMovies(),
            'movie' => $this->getMovieDetail($id),
            'casts' => $this->getCasts($id),
            'genres' => $this->getGenres($id),
            'watchlist' => $this->getWatchlist(),
            'user' => Auth::user()->role
        ]);
    }

    public function removeMovie(Request $request){
        if($request->ajax()){
            Movie::where('id', $request->movie_id)->delete();
        }
    }

    public function getCasts($id){
        return DB::table('movies')
                ->select(DB::raw('actors.id as id'), 'name', 'image', 'character')
                ->join('movie_actors', 'movie_id', '=', 'movies.id')
                ->join('actors', 'actor_id', '=', 'actors.id')
                ->where('movie_id', $id)
                ->get();
    }

    public function getGenres($id){
        return DB::table('movies')
        ->select('genre')
        ->join('movie_genres', 'movie_id', '=', 'movies.id')
        ->join('genres', 'genre_id', '=', 'genres.id')
        ->where('movie_id', $id)
        ->get();
    }

    public function getMovieDetail($id){
        return DB::table('movies')
                ->select(DB::raw('movies.id as id'), 'title', 'thumbnail', 'description', 'director', 'background', DB::raw('YEAR(release_date) as date'))
                ->join('movie_actors', 'movie_id', '=', 'movies.id')
                ->join('actors', 'actor_id', '=', 'actors.id')
                ->where('movie_id', $id)
                ->get();
    }

    public function getMoreMovies(){
        return DB::table('movies')
                ->select(DB::raw('movies.id as id'), 'title', 'thumbnail', DB::raw('YEAR(release_date) as date'))
                ->inRandomOrder()
                ->limit(5)
                ->get();
    }

    public function getWatchlist(){
        $username = Auth::user()->username;
        return DB::table('watchlists')
                ->join('users', 'users.id', '=', 'user_id')
                ->where('username', $username)
                ->get();
    }
}
