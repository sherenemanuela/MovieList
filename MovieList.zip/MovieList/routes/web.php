<?php

use App\Http\Controllers\ActorController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\GuestController;
use App\Http\Controllers\MovieController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\MovieDetailController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\WatchlistController;
use App\Models\Actor;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Route::get('remove-movie', [MovieDetailController::class, 'removeMovie']);
Route::get('/', [GuestController::class, 'guestPage']);
Route::get('/login', [AuthController::class, 'loginPage']);
Route::post('/login', [AuthController::class, 'login']);
Route::get('/register', [AuthController::class, 'registerPage']);
Route::post('/register', [AuthController::class, 'register']);
Route::get('/admin', [AuthController::class, 'adminPage'])->middleware('admin');
Route::get('/admin', [AdminController::class, 'adminPage'])->middleware('admin')->name('admin');
Route::get('/add-movie', [MovieController::class, 'addMoviePage'])->middleware('admin');
Route::post('/add-movie', [MovieController::class, 'addMovie'])->middleware('admin');
Route::get('/edit-movie-{id}', [MovieController::class, 'editMoviePage'])->middleware('admin');
Route::post('/edit-movie-{id}', [MovieController::class, 'editMovie'])->middleware('admin');
Route::get('delete-movie-{id}', [MovieController::class, 'deleteMovie'])->middleware('admin');
Route::get('/add-actor', [ActorController::class, 'addActorPage'])->middleware('admin');
Route::post('/add-actor', [ActorController::class, 'addActor'])->middleware('admin');
Route::get('/edit-actor-{id}-{name}', [ActorController::class, 'editActorPage'])->middleware('admin');
Route::post('/edit-actor-{id}-{name}', [ActorController::class, 'editActor'])->middleware('admin');
Route::get('delete-actor-{id}-{name}', [ActorController::class, 'deleteActor'])->middleware('admin');
Route::get('home-search', [GuestController::class, 'search']);
Route::get('genre', [GuestController::class, 'genre']);
Route::get('sort-latest', [GuestController::class, 'sortLatest']);
Route::get('sort-desc', [GuestController::class, 'sortDesc']);
Route::get('sort-asc', [GuestController::class, 'sortAsc']);
Route::get('/actors', [ActorController::class, 'showActor']);
Route::get('actor-search', [ActorController::class, 'search']);
Route::get('/actors-{id}-{name}', [ActorController::class, 'actorDetail']);
Route::get('/browse', [UserController::class, 'userPage'])->middleware('user');
Route::get('/add-watchlist', [UserController::class, 'addWatchlist'])->middleware('user');
Route::get('/remove-watchlist', [UserController::class, 'removeWatchlist'])->middleware('user');
Route::get('/watchlist', [WatchlistController::class, 'watchlistPage'])->middleware('user');
Route::get('watchlist-search', [WatchlistController::class, 'search']);
Route::get('update-watchlist', [WatchlistController::class, 'updateStatus']);
Route::get('filter-watchlist', [WatchlistController::class, 'filterWatchlist']);
Route::get('/profile', [ProfileController::class, 'profilePage'])->middleware('registered');
Route::post('/update-profile', [ProfileController::class, 'updateProfile'])->middleware('registered');
Route::get('update-profile-picture', [ProfileController::class, 'updateProfilePicture']);
Route::get('/movie-detail-{id}', [MovieDetailController::class, 'movieDetailPage']);
Route::get('logout', [AuthController::class, 'logout']);
