<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateMovieActorsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('movie_actors', function (Blueprint $table) {
            $table->id();
            $table->foreignId('movie_id');
            $table->foreign('movie_id')
                    ->references('id')
                    ->on('movies')
                    ->onUpdate('cascade')
                    ->onDelete('cascade');
            $table->foreignId('actor_id');
            $table->foreign('actor_id')
                    ->references('id')
                    ->on('actors')
                    ->onUpdate('cascade')
                    ->onDelete('cascade');
            $table->string('character');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('movie_actors');
    }
}
