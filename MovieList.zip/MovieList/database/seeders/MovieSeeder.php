<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class MovieSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('movies')->insert([[
            'title' => 'The Menu',
            'description' => 'A young couple travels to a remote island to eat at an exclusive restaurant where the chef has prepared a lavish menu, with some shocking surprises.',
            'director' => 'Mark Mylod',
            'release_date' => '2022-09-10',
            'thumbnail' => 'the-menu.jpg',
            'background' => 'the-menu.jpg'
        ],
        [
            'title' => 'Black Panther',
            'description' => 'The people of Wakanda fight to protect their home from intervening world powers as they mourn the death of King T\'Challa.',
            'director' => 'Ryan Coogler',
            'release_date' => '2022-11-11',
            'thumbnail' => 'black-panther.jpg',
            'background' => 'black-panther.jpg'
        ],
        [
            'title' => 'Spirited',
            'description' => 'A musical version of Charles Dickens\'s story of a miserly misanthrope who is taken on a magical journey.',
            'director' => 'Sean Anders',
            'release_date' => '2022-11-11',
            'thumbnail' => 'spirited.png',
            'background' => 'spirited.jpg'
        ],
        [
            'title' => 'The Dark Knight',
            'description' => 'When Joker wreaks havoc and chaos on the people of Gotham, Batman must accept the tests of his ability to fight injustice.',
            'director' => 'Christopher Nolan',
            'release_date' => '2008-07-18',
            'thumbnail' => 'the-dark-knight.jpg',
            'background' => 'the-dark-knight.jpg'
        ],
        [
            'title' => 'The Matrix',
            'description' => 'When a beautiful stranger leads computer hacker Neo to a forbidding underworld, he discovers the shocking truth--the life he knows is the elaborate deception of an evil cyber-intelligence.',
            'director' => 'Lana Wachowski',
            'release_date' => '1999-03-24',
            'thumbnail' => 'the-matrix.jpg',
            'background' => 'the-matrix.jpg'
        ]]);
    }
}
