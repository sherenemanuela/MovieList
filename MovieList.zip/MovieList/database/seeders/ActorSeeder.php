<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class ActorSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('actors')->insert([[
            'name' => 'Ralph Fiennes',
            'gender' => 'Male',
            'biography' => 'The eldest of six children',
            'dob' => '1962-12-22',
            'birth_place' => 'England',
            'image' => 'ralph-fiennes.jpg',
            'popularity' => 1,
        ],
        [
            'name' => 'Anya Taylor Joy',
            'gender' => 'Female',
            'biography' => 'the youngest of six children',
            'dob' => '1996-04-16',
            'birth_place' => 'Miami',
            'image' => 'anya-taylor-joy.jpg',
            'popularity' => 2,
        ],
        [
            'name' => 'Letitia Wright',
            'gender' => 'Female',
            'biography' => 'Emmy-nominated Letitia Wright has cemented her position as one of the industry\'s most captivating young actresses.',
            'dob' => '1993-10-31',
            'birth_place' => 'Guyana',
            'image' => 'letitia-wright.jpg',
            'popularity' => 3,
        ],
        [
            'name' => 'Ryan Reynolds',
            'gender' => 'Male',
            'biography' => 'He has Irish and Scottish ancestry.',
            'dob' => '1976-10-23',
            'birth_place' => 'Vancouver',
            'image' => 'ryan-reynolds.jpg',
            'popularity' => 4,
        ],
        [
            'name' => 'Christian Bale',
            'gender' => 'Male',
            'biography' => 'Bale acknowledges the constant change was one of the influences on his career choice.',
            'dob' => '1974-01-30',
            'birth_place' => 'Haverfordwest',
            'image' => 'christian-bale.jpg',
            'popularity' => 5
        ],
        [
            'name' => 'Keanu Reeves',
            'gender' => 'Male',
            'biography' => 'Keanu Charles Reeves, whose first name means "cool breeze over the mountains".',
            'dob' => '1964-09-02',
            'birth_place' => 'Beirut',
            'image' => 'keanu-reeves.jpg',
            'popularity' => 6
        ]]);
    }
}
