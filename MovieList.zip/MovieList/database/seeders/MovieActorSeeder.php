<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class MovieActorSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('movie_actors')->insert([[
            'movie_id' => '1',
            'actor_id' => '1',
            'character' => 'Julian Slowik'
        ],
        [
            'movie_id' => '1',
            'actor_id' => '2',
            'character' => 'Margot Mills'
        ],
        [
            'movie_id' => '2',
            'actor_id' => '3',
            'character' => 'Shuri'
        ],
        [
            'movie_id' => '3',
            'actor_id' => '4',
            'character' => 'Clint Briggs'
        ],
        [
            'movie_id' => '4',
            'actor_id' => '5',
            'character' => 'Bruce Wayne'
        ],
        [
            'movie_id' => '5',
            'actor_id' => '6',
            'character' => 'Thomas Anderson'
        ]]);
    }
}
